export interface Alarm {
  id: string;
  time: string; // HH:MM
  date: string; // YYYY-MM-DD
  label: string;
  enabled: boolean;
  repeat: string[]; // days of week
  sound: string;
  triggered: boolean;
}

export interface WaterReminder {
  id: string;
  enabled: boolean;
  wakeTime: string; // HH:MM
  sleepTime: string; // HH:MM
  intervalMinutes: number;
  message: string;
  lastTriggered: string | null;
}

export type TabType = 'alarm' | 'water' | 'stopwatch';
