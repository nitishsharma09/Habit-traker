import { useState } from 'react';
import { Droplets, Clock, Moon, Sun, Plus, Trash2, Zap } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import type { WaterReminder } from '../types';

interface WaterTabProps {
  reminders: WaterReminder[];
  setReminders: (reminders: WaterReminder[] | ((prev: WaterReminder[]) => WaterReminder[])) => void;
  waterCount: number;
  setWaterCount: (count: number | ((prev: number) => number)) => void;
}

export function WaterTab({ reminders, setReminders, waterCount, setWaterCount }: WaterTabProps) {
  const [showForm, setShowForm] = useState(false);
  const [wakeTime, setWakeTime] = useState('07:00');
  const [sleepTime, setSleepTime] = useState('23:00');
  const [intervalMinutes, setIntervalMinutes] = useState(60);
  const [message, setMessage] = useState('Please drink water! 💧 Stay hydrated!');

  const dailyGoal = 8;
  const progress = Math.min((waterCount / dailyGoal) * 100, 100);

  const handleAddReminder = () => {
    const newReminder: WaterReminder = {
      id: uuidv4(),
      enabled: true,
      wakeTime,
      sleepTime,
      intervalMinutes,
      message,
      lastTriggered: null,
    };
    setReminders((prev: WaterReminder[]) => [...prev, newReminder]);
    setShowForm(false);
  };

  const toggleReminder = (id: string) => {
    setReminders((prev: WaterReminder[]) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  };

  const deleteReminder = (id: string) => {
    setReminders((prev: WaterReminder[]) => prev.filter((r) => r.id !== id));
  };

  const intervalOptions = [
    { label: '30 min', value: 30 },
    { label: '1 hour', value: 60 },
    { label: '1.5 hrs', value: 90 },
    { label: '2 hours', value: 120 },
  ];

  const getScheduledTimes = (reminder: WaterReminder) => {
    const times: string[] = [];
    const [wh, wm] = reminder.wakeTime.split(':').map(Number);
    const [sh, sm] = reminder.sleepTime.split(':').map(Number);
    let current = wh * 60 + wm;
    const end = sh * 60 + sm;
    
    while (current <= end) {
      const h = Math.floor(current / 60);
      const m = current % 60;
      times.push(`${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`);
      current += reminder.intervalMinutes;
    }
    return times;
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-5 pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">💧 Water Reminder</h1>
            <p className="text-sm text-slate-400 mt-1">Stay hydrated throughout the day</p>
          </div>
          <button
            onClick={() => setShowForm(true)}
            className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500 to-blue-600 shadow-lg shadow-blue-500/30 active:scale-90 transition-transform"
          >
            <Plus className="h-6 w-6 text-white" />
          </button>
        </div>
      </div>

      {/* Water Tracker */}
      <div className="px-4 mb-4">
        <div className="rounded-2xl bg-gradient-to-br from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 p-5">
          <div className="flex items-center justify-between mb-4">
            <div>
              <p className="text-cyan-300 font-semibold text-sm">Today's Water Intake</p>
              <p className="text-3xl font-bold text-white mt-1">
                {waterCount} <span className="text-lg text-slate-400">/ {dailyGoal} glasses</span>
              </p>
            </div>
            <div className="relative h-20 w-20">
              <svg className="h-20 w-20 -rotate-90" viewBox="0 0 80 80">
                <circle cx="40" cy="40" r="34" fill="none" stroke="rgba(100,200,255,0.1)" strokeWidth="6" />
                <circle
                  cx="40" cy="40" r="34" fill="none"
                  stroke="url(#waterGrad)"
                  strokeWidth="6"
                  strokeLinecap="round"
                  strokeDasharray={`${progress * 2.136} 213.6`}
                />
                <defs>
                  <linearGradient id="waterGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#06b6d4" />
                    <stop offset="100%" stopColor="#3b82f6" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-lg font-bold text-cyan-300">{Math.round(progress)}%</span>
              </div>
            </div>
          </div>
          
          {/* Water glasses visual */}
          <div className="flex gap-2 mb-4 flex-wrap">
            {Array.from({ length: dailyGoal }).map((_, i) => (
              <div
                key={i}
                className={`h-8 w-8 rounded-lg flex items-center justify-center text-sm transition-all duration-300 ${
                  i < waterCount
                    ? 'bg-cyan-500/30 text-cyan-300 scale-100'
                    : 'bg-slate-800/50 text-slate-700 scale-90'
                }`}
              >
                {i < waterCount ? '💧' : '○'}
              </div>
            ))}
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setWaterCount((prev: number) => Math.max(0, prev - 1))}
              className="flex-1 rounded-xl bg-slate-800/60 py-2.5 text-slate-400 font-semibold text-sm active:scale-95 transition-transform"
            >
              − Remove
            </button>
            <button
              onClick={() => setWaterCount((prev: number) => prev + 1)}
              className="flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 py-2.5 text-white font-semibold text-sm shadow-lg shadow-cyan-500/20 active:scale-95 transition-transform flex items-center justify-center gap-1"
            >
              <Droplets className="h-4 w-4" /> + Drink Water
            </button>
          </div>
        </div>
      </div>

      {/* Reminders List */}
      <div className="px-4 space-y-3">
        <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider px-1 flex items-center gap-2">
          <Zap className="h-4 w-4" /> Active Reminders
        </h3>

        {reminders.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <div className="h-20 w-20 rounded-full bg-slate-800/50 flex items-center justify-center mb-3">
              <Droplets className="h-10 w-10 text-slate-600" />
            </div>
            <p className="text-slate-400 font-medium text-sm">No water reminders</p>
            <p className="text-slate-600 text-xs mt-1">Tap + to set up reminders</p>
          </div>
        )}

        {reminders.map((reminder) => (
          <div
            key={reminder.id}
            className={`rounded-2xl border transition-all ${
              reminder.enabled
                ? 'bg-slate-800/80 border-cyan-500/20'
                : 'bg-slate-900/50 border-slate-800/30 opacity-60'
            }`}
          >
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs px-2 py-1 rounded-full bg-cyan-500/15 text-cyan-300 flex items-center gap-1">
                      <Sun className="h-3 w-3" /> {reminder.wakeTime}
                    </span>
                    <span className="text-slate-600">→</span>
                    <span className="text-xs px-2 py-1 rounded-full bg-indigo-500/15 text-indigo-300 flex items-center gap-1">
                      <Moon className="h-3 w-3" /> {reminder.sleepTime}
                    </span>
                  </div>
                  <p className="text-sm text-slate-300 mb-2">
                    Every <span className="text-cyan-400 font-semibold">{reminder.intervalMinutes} min</span> — "{reminder.message}"
                  </p>
                  
                  {/* Scheduled times */}
                  <div className="flex flex-wrap gap-1">
                    {getScheduledTimes(reminder).map((t, i) => (
                      <span key={i} className="text-[10px] px-1.5 py-0.5 rounded bg-slate-700/50 text-slate-400">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="flex flex-col items-center gap-2">
                  <button
                    onClick={() => toggleReminder(reminder.id)}
                    className={`relative h-7 w-12 rounded-full transition-colors duration-300 ${
                      reminder.enabled ? 'bg-cyan-500' : 'bg-slate-700'
                    }`}
                  >
                    <div
                      className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-300 ${
                        reminder.enabled ? 'translate-x-5.5' : 'translate-x-0.5'
                      }`}
                    />
                  </button>
                  <button
                    onClick={() => deleteReminder(reminder.id)}
                    className="p-1.5 rounded-lg text-slate-600 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add Reminder Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div
            className="w-full max-w-lg rounded-t-3xl bg-slate-800 border-t border-slate-700/50 p-6 pb-8 animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-6 h-1 w-10 rounded-full bg-slate-600" />
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              💧 New Water Reminder
            </h2>

            <div className="space-y-5">
              {/* Wake Time */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Sun className="h-3.5 w-3.5 text-amber-400" /> Wake Up Time
                </label>
                <input
                  type="time"
                  value={wakeTime}
                  onChange={(e) => setWakeTime(e.target.value)}
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-2xl font-light text-white text-center focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Sleep Time */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Moon className="h-3.5 w-3.5 text-indigo-400" /> Sleep Time
                </label>
                <input
                  type="time"
                  value={sleepTime}
                  onChange={(e) => setSleepTime(e.target.value)}
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-2xl font-light text-white text-center focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>

              {/* Interval */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Clock className="h-3.5 w-3.5" /> Remind Every
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {intervalOptions.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => setIntervalMinutes(opt.value)}
                      className={`rounded-xl py-3 text-sm font-semibold transition-all ${
                        intervalMinutes === opt.value
                          ? 'bg-cyan-500 text-white shadow-lg shadow-cyan-500/30'
                          : 'bg-slate-900/60 text-slate-400 border border-slate-700'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Message */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">
                  Reminder Message
                </label>
                <input
                  type="text"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Your reminder message..."
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 mt-8">
              <button
                onClick={() => setShowForm(false)}
                className="flex-1 rounded-xl bg-slate-700/50 px-4 py-3.5 text-slate-300 font-medium active:scale-95 transition-transform"
              >
                Cancel
              </button>
              <button
                onClick={handleAddReminder}
                className="flex-1 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-500 px-4 py-3.5 text-white font-semibold shadow-lg shadow-cyan-500/30 active:scale-95 transition-transform flex items-center justify-center gap-2"
              >
                <Droplets className="h-4 w-4" /> Set Reminder
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
