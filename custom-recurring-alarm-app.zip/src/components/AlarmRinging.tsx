import { useEffect, useRef, useState } from 'react';
import { BellRing, X, Volume2 } from 'lucide-react';
import type { Alarm } from '../types';

interface AlarmRingingProps {
  alarm: Alarm;
  onDismiss: () => void;
  onSnooze: () => void;
}

export function AlarmRinging({ alarm, onDismiss, onSnooze }: AlarmRingingProps) {
  const [pulse, setPulse] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    const iv = setInterval(() => setPulse((p) => !p), 500);
    return () => clearInterval(iv);
  }, []);

  // Play alarm sound using Web Audio API
  useEffect(() => {
    try {
      const ctx = new AudioContext();
      audioContextRef.current = ctx;

      const playBeep = () => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.frequency.value = 880;
        osc.type = 'sine';
        gain.gain.setValueAtTime(0.3, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.5);

        setTimeout(() => {
          const osc2 = ctx.createOscillator();
          const gain2 = ctx.createGain();
          osc2.connect(gain2);
          gain2.connect(ctx.destination);
          osc2.frequency.value = 1100;
          osc2.type = 'sine';
          gain2.gain.setValueAtTime(0.3, ctx.currentTime);
          gain2.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
          osc2.start(ctx.currentTime);
          osc2.stop(ctx.currentTime + 0.5);
        }, 300);
      };

      playBeep();
      intervalRef.current = window.setInterval(playBeep, 2000);
    } catch {
      // Audio not supported
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (audioContextRef.current) audioContextRef.current.close();
    };
  }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-xl">
      <div className="flex flex-col items-center gap-8 px-6 text-center">
        {/* Animated Bell */}
        <div className={`relative transition-transform duration-300 ${pulse ? 'scale-110 rotate-6' : 'scale-100 -rotate-6'}`}>
          <div className="absolute inset-0 rounded-full bg-amber-500/30 blur-3xl animate-pulse" style={{ width: 200, height: 200, marginLeft: -40, marginTop: -40 }} />
          <div className="relative flex h-32 w-32 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 shadow-2xl shadow-amber-500/50">
            <BellRing className="h-16 w-16 text-white" />
          </div>
        </div>

        {/* Time */}
        <div>
          <p className="text-7xl font-thin text-white tracking-wider">{alarm.time}</p>
          <p className="mt-3 text-xl text-amber-300 font-medium">{alarm.label || 'Alarm'}</p>
        </div>

        {/* Sound indicator */}
        <div className="flex items-center gap-2 text-amber-400/70">
          <Volume2 className="h-4 w-4 animate-pulse" />
          <span className="text-sm">Alarm ringing...</span>
        </div>

        {/* Buttons */}
        <div className="flex gap-6 mt-8">
          <button
            onClick={onSnooze}
            className="flex flex-col items-center gap-2 rounded-2xl bg-white/10 px-8 py-4 text-white backdrop-blur-sm border border-white/10 active:scale-95 transition-transform"
          >
            <span className="text-2xl">😴</span>
            <span className="text-sm font-medium">Snooze</span>
            <span className="text-xs text-white/50">5 min</span>
          </button>
          <button
            onClick={onDismiss}
            className="flex flex-col items-center gap-2 rounded-2xl bg-red-500/80 px-8 py-4 text-white shadow-lg shadow-red-500/30 active:scale-95 transition-transform"
          >
            <X className="h-6 w-6" />
            <span className="text-sm font-medium">Dismiss</span>
            <span className="text-xs text-white/70">Stop</span>
          </button>
        </div>
      </div>
    </div>
  );
}
