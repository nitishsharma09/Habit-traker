import { useState } from 'react';
import { Plus, Trash2, Clock, Calendar, Tag, Bell } from 'lucide-react';
import { v4 as uuidv4 } from 'uuid';
import type { Alarm } from '../types';

interface AlarmTabProps {
  alarms: Alarm[];
  setAlarms: (alarms: Alarm[] | ((prev: Alarm[]) => Alarm[])) => void;
}

export function AlarmTab({ alarms, setAlarms }: AlarmTabProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [time, setTime] = useState('07:00');
  const [date, setDate] = useState(() => {
    const d = new Date();
    return d.toISOString().split('T')[0];
  });
  const [label, setLabel] = useState('');
  const [repeatDays, setRepeatDays] = useState<string[]>([]);

  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const toggleDay = (day: string) => {
    setRepeatDays((prev) =>
      prev.includes(day) ? prev.filter((d) => d !== day) : [...prev, day]
    );
  };

  const handleSave = () => {
    if (editingId) {
      setAlarms((prev: Alarm[]) =>
        prev.map((a) =>
          a.id === editingId
            ? { ...a, time, date, label, repeat: repeatDays }
            : a
        )
      );
    } else {
      const newAlarm: Alarm = {
        id: uuidv4(),
        time,
        date,
        label: label || 'Alarm',
        enabled: true,
        repeat: repeatDays,
        sound: 'default',
        triggered: false,
      };
      setAlarms((prev: Alarm[]) => [...prev, newAlarm]);
    }
    resetForm();
  };

  const resetForm = () => {
    setShowForm(false);
    setEditingId(null);
    setTime('07:00');
    setDate(new Date().toISOString().split('T')[0]);
    setLabel('');
    setRepeatDays([]);
  };

  const toggleAlarm = (id: string) => {
    setAlarms((prev: Alarm[]) =>
      prev.map((a) =>
        a.id === id ? { ...a, enabled: !a.enabled, triggered: false } : a
      )
    );
  };

  const deleteAlarm = (id: string) => {
    setAlarms((prev: Alarm[]) => prev.filter((a) => a.id !== id));
  };

  const editAlarm = (alarm: Alarm) => {
    setTime(alarm.time);
    setDate(alarm.date);
    setLabel(alarm.label);
    setRepeatDays(alarm.repeat);
    setEditingId(alarm.id);
    setShowForm(true);
  };

  const getTimeUntilAlarm = (alarm: Alarm): string => {
    const now = new Date();
    const [h, m] = alarm.time.split(':').map(Number);
    const alarmDate = new Date(alarm.date);
    alarmDate.setHours(h, m, 0, 0);
    
    if (alarmDate <= now) {
      if (alarm.repeat.length > 0) return 'Repeating';
      return 'Passed';
    }
    
    const diff = alarmDate.getTime() - now.getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    
    if (hours > 24) {
      const d = Math.floor(hours / 24);
      return `${d} day${d > 1 ? 's' : ''} left`;
    }
    return `${hours}h ${mins}m left`;
  };

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr + 'T00:00:00');
    return d.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
  };

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-5 pt-6 pb-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">⏰ Alarms</h1>
            <p className="text-sm text-slate-400 mt-1">
              {alarms.filter(a => a.enabled).length} active alarm{alarms.filter(a => a.enabled).length !== 1 ? 's' : ''}
            </p>
          </div>
          <button
            onClick={() => { resetForm(); setShowForm(true); }}
            className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-violet-500 to-indigo-600 shadow-lg shadow-indigo-500/30 active:scale-90 transition-transform"
          >
            <Plus className="h-6 w-6 text-white" />
          </button>
        </div>
      </div>

      {/* Alarm List */}
      <div className="px-4 space-y-3">
        {alarms.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16 text-center">
            <div className="h-24 w-24 rounded-full bg-slate-800/50 flex items-center justify-center mb-4">
              <Clock className="h-12 w-12 text-slate-600" />
            </div>
            <p className="text-slate-400 font-medium">No alarms set</p>
            <p className="text-slate-600 text-sm mt-1">Tap + to add your first alarm</p>
          </div>
        )}

        {alarms.map((alarm) => (
          <div
            key={alarm.id}
            className={`rounded-2xl border transition-all duration-300 ${
              alarm.enabled
                ? 'bg-slate-800/80 border-slate-700/50'
                : 'bg-slate-900/50 border-slate-800/30 opacity-60'
            }`}
          >
            <div className="flex items-center p-4 gap-3">
              <div className="flex-1 min-w-0" onClick={() => editAlarm(alarm)}>
                <div className="flex items-baseline gap-2">
                  <span className={`text-4xl font-extralight tracking-wider ${alarm.enabled ? 'text-white' : 'text-slate-500'}`}>
                    {alarm.time}
                  </span>
                </div>
                <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-300 flex items-center gap-1">
                    <Tag className="h-3 w-3" />{alarm.label}
                  </span>
                  <span className="text-xs px-2 py-0.5 rounded-full bg-slate-700/50 text-slate-400 flex items-center gap-1">
                    <Calendar className="h-3 w-3" />{formatDate(alarm.date)}
                  </span>
                </div>
                {alarm.repeat.length > 0 && (
                  <div className="flex gap-1 mt-2">
                    {days.map((d) => (
                      <span
                        key={d}
                        className={`text-[10px] w-6 h-6 flex items-center justify-center rounded-full ${
                          alarm.repeat.includes(d)
                            ? 'bg-indigo-500/30 text-indigo-300 font-semibold'
                            : 'text-slate-600'
                        }`}
                      >
                        {d[0]}
                      </span>
                    ))}
                  </div>
                )}
                {alarm.enabled && (
                  <p className="text-[11px] text-emerald-400 mt-1.5 font-medium">
                    🔔 {getTimeUntilAlarm(alarm)}
                  </p>
                )}
              </div>
              <div className="flex flex-col items-center gap-3">
                {/* Toggle switch */}
                <button
                  onClick={() => toggleAlarm(alarm.id)}
                  className={`relative h-7 w-12 rounded-full transition-colors duration-300 ${
                    alarm.enabled ? 'bg-indigo-500' : 'bg-slate-700'
                  }`}
                >
                  <div
                    className={`absolute top-0.5 h-6 w-6 rounded-full bg-white shadow-md transition-transform duration-300 ${
                      alarm.enabled ? 'translate-x-5.5' : 'translate-x-0.5'
                    }`}
                  />
                </button>
                <button
                  onClick={() => deleteAlarm(alarm.id)}
                  className="p-1.5 rounded-lg text-slate-600 hover:text-red-400 hover:bg-red-500/10 transition-colors"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit Alarm Modal */}
      {showForm && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/60 backdrop-blur-sm" onClick={resetForm}>
          <div
            className="w-full max-w-lg rounded-t-3xl bg-slate-800 border-t border-slate-700/50 p-6 pb-8 animate-slide-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mx-auto mb-6 h-1 w-10 rounded-full bg-slate-600" />
            <h2 className="text-xl font-bold text-white mb-6 flex items-center gap-2">
              {editingId ? '✏️ Edit Alarm' : '⏰ New Alarm'}
            </h2>

            <div className="space-y-5">
              {/* Time */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Clock className="h-3.5 w-3.5" /> Time
                </label>
                <input
                  type="time"
                  value={time}
                  onChange={(e) => setTime(e.target.value)}
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-3xl font-light text-white text-center focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>

              {/* Date */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Calendar className="h-3.5 w-3.5" /> Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-white focus:outline-none focus:border-indigo-500 transition-colors [color-scheme:dark]"
                />
              </div>

              {/* Label */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider flex items-center gap-1.5 mb-2">
                  <Tag className="h-3.5 w-3.5" /> Label
                </label>
                <input
                  type="text"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="e.g., Wake up, Meeting..."
                  className="w-full rounded-xl bg-slate-900/80 border border-slate-700 px-4 py-3 text-white placeholder-slate-600 focus:outline-none focus:border-indigo-500 transition-colors"
                />
              </div>

              {/* Repeat Days */}
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2 block">
                  Repeat
                </label>
                <div className="flex gap-2">
                  {days.map((day) => (
                    <button
                      key={day}
                      onClick={() => toggleDay(day)}
                      className={`flex-1 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                        repeatDays.includes(day)
                          ? 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30'
                          : 'bg-slate-900/60 text-slate-500 border border-slate-700'
                      }`}
                    >
                      {day}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Buttons */}
            <div className="flex gap-3 mt-8">
              <button
                onClick={resetForm}
                className="flex-1 rounded-xl bg-slate-700/50 px-4 py-3.5 text-slate-300 font-medium active:scale-95 transition-transform"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="flex-1 rounded-xl bg-gradient-to-r from-indigo-500 to-violet-500 px-4 py-3.5 text-white font-semibold shadow-lg shadow-indigo-500/30 active:scale-95 transition-transform flex items-center justify-center gap-2"
              >
                <Bell className="h-4 w-4" />
                {editingId ? 'Update' : 'Set Alarm'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
