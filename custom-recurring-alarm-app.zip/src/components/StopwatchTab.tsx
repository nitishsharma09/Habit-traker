import { useState, useRef, useEffect } from 'react';
import { Play, Pause, RotateCcw, Flag, Timer } from 'lucide-react';

export function StopwatchTab() {
  const [time, setTime] = useState(0);
  const [running, setRunning] = useState(false);
  const [laps, setLaps] = useState<number[]>([]);
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = window.setInterval(() => {
        setTime((prev) => prev + 10);
      }, 10);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running]);

  const formatTime = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const centiseconds = Math.floor((ms % 1000) / 10);
    return {
      min: minutes.toString().padStart(2, '0'),
      sec: seconds.toString().padStart(2, '0'),
      cs: centiseconds.toString().padStart(2, '0'),
    };
  };

  const handleReset = () => {
    setRunning(false);
    setTime(0);
    setLaps([]);
  };

  const handleLap = () => {
    setLaps((prev) => [time, ...prev]);
  };

  const { min, sec, cs } = formatTime(time);

  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-5 pt-6 pb-4">
        <h1 className="text-2xl font-bold text-white flex items-center gap-2">
          <Timer className="h-6 w-6 text-emerald-400" /> Stopwatch
        </h1>
        <p className="text-sm text-slate-400 mt-1">Track your time accurately</p>
      </div>

      {/* Timer Display */}
      <div className="px-4 mb-6">
        <div className="rounded-3xl bg-gradient-to-br from-slate-800/80 to-slate-900/80 border border-slate-700/30 p-8 text-center">
          <div className="flex items-baseline justify-center gap-1">
            <span className="text-7xl font-extralight text-white tracking-wider font-mono">{min}</span>
            <span className="text-4xl text-slate-500 font-light">:</span>
            <span className="text-7xl font-extralight text-white tracking-wider font-mono">{sec}</span>
            <span className="text-4xl text-slate-500 font-light">.</span>
            <span className="text-4xl font-extralight text-emerald-400 tracking-wider font-mono w-12">{cs}</span>
          </div>
          
          {/* Progress ring */}
          <div className="flex justify-center mt-6">
            <svg className="h-4 w-64" viewBox="0 0 260 4">
              <rect x="0" y="0" width="260" height="4" rx="2" fill="rgba(100,116,139,0.2)" />
              <rect
                x="0" y="0"
                width={running ? '260' : '0'}
                height="4" rx="2"
                fill="url(#timerGrad)"
                className="transition-all duration-300"
              >
                {running && (
                  <animate attributeName="width" from="0" to="260" dur="60s" repeatCount="indefinite" />
                )}
              </rect>
              <defs>
                <linearGradient id="timerGrad" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="100%" stopColor="#06b6d4" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </div>

      {/* Controls */}
      <div className="flex justify-center gap-5 mb-8 px-4">
        <button
          onClick={handleReset}
          className="flex h-16 w-16 items-center justify-center rounded-2xl bg-slate-800 border border-slate-700/50 text-slate-400 active:scale-90 transition-transform"
        >
          <RotateCcw className="h-6 w-6" />
        </button>
        <button
          onClick={() => setRunning(!running)}
          className={`flex h-20 w-20 items-center justify-center rounded-full shadow-xl active:scale-90 transition-all ${
            running
              ? 'bg-gradient-to-br from-red-500 to-rose-600 shadow-red-500/30'
              : 'bg-gradient-to-br from-emerald-500 to-green-600 shadow-emerald-500/30'
          }`}
        >
          {running ? <Pause className="h-8 w-8 text-white" /> : <Play className="h-8 w-8 text-white ml-1" />}
        </button>
        <button
          onClick={handleLap}
          disabled={!running}
          className={`flex h-16 w-16 items-center justify-center rounded-2xl border active:scale-90 transition-transform ${
            running
              ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
              : 'bg-slate-800 border-slate-700/50 text-slate-600'
          }`}
        >
          <Flag className="h-6 w-6" />
        </button>
      </div>

      {/* Laps */}
      {laps.length > 0 && (
        <div className="px-4">
          <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider px-1 mb-3 flex items-center gap-2">
            <Flag className="h-4 w-4" /> Laps ({laps.length})
          </h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {laps.map((lap, index) => {
              const lapTime = formatTime(index === 0 ? lap : lap - (laps[index + 1] || 0));
              const totalTime = formatTime(lap);
              return (
                <div
                  key={index}
                  className="flex items-center justify-between rounded-xl bg-slate-800/60 border border-slate-700/30 px-4 py-3"
                >
                  <span className="text-slate-400 text-sm font-medium">
                    Lap {laps.length - index}
                  </span>
                  <div className="flex gap-6">
                    <span className="text-emerald-400 font-mono text-sm">
                      +{lapTime.min}:{lapTime.sec}.{lapTime.cs}
                    </span>
                    <span className="text-white font-mono text-sm">
                      {totalTime.min}:{totalTime.sec}.{totalTime.cs}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
