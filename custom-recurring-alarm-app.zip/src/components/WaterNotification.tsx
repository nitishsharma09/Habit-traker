import { useEffect, useState } from 'react';
import { Droplets, X } from 'lucide-react';

interface WaterNotificationProps {
  message: string;
  onDismiss: () => void;
}

export function WaterNotification({ message, onDismiss }: WaterNotificationProps) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setTimeout(() => setVisible(true), 50);
    const timer = setTimeout(() => {
      setVisible(false);
      setTimeout(onDismiss, 300);
    }, 8000);
    return () => clearTimeout(timer);
  }, [onDismiss]);

  return (
    <div className={`fixed top-4 left-4 right-4 z-40 transition-all duration-300 ${visible ? 'translate-y-0 opacity-100' : '-translate-y-full opacity-0'}`}>
      <div className="rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-500 p-4 shadow-2xl shadow-blue-500/30 flex items-center gap-3">
        <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur-sm shrink-0">
          <Droplets className="h-7 w-7 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-white font-semibold text-sm">💧 Water Reminder</p>
          <p className="text-white/90 text-xs mt-0.5">{message}</p>
        </div>
        <button onClick={() => { setVisible(false); setTimeout(onDismiss, 300); }} className="shrink-0 rounded-full bg-white/20 p-1.5">
          <X className="h-4 w-4 text-white" />
        </button>
      </div>
    </div>
  );
}
