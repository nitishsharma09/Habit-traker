import { useState, useEffect, useCallback, useRef } from 'react';
import { AlarmClock, Droplets, Timer, Bell } from 'lucide-react';
import { AlarmTab } from './components/AlarmTab';
import { WaterTab } from './components/WaterTab';
import { StopwatchTab } from './components/StopwatchTab';
import { AlarmRinging } from './components/AlarmRinging';
import { WaterNotification } from './components/WaterNotification';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useNotification } from './hooks/useNotification';
import type { Alarm, WaterReminder, TabType } from './types';

export function App() {
  const [activeTab, setActiveTab] = useState<TabType>('alarm');
  const [alarms, setAlarms] = useLocalStorage<Alarm[]>('alarms', []);
  const [waterReminders, setWaterReminders] = useLocalStorage<WaterReminder[]>('waterReminders', []);
  const [waterCount, setWaterCount] = useLocalStorage<number>('waterCount', 0);
  const [waterCountDate, setWaterCountDate] = useLocalStorage<string>('waterCountDate', new Date().toDateString());
  const [ringingAlarm, setRingingAlarm] = useState<Alarm | null>(null);
  const [showWaterNotif, setShowWaterNotif] = useState(false);
  const [waterNotifMessage, setWaterNotifMessage] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [notificationPermission, setNotificationPermission] = useState(false);
  const { sendNotification, requestPermission } = useNotification();
  const snoozeTimerRef = useRef<number | null>(null);

  // Reset water count daily
  useEffect(() => {
    const today = new Date().toDateString();
    if (waterCountDate !== today) {
      setWaterCount(0);
      setWaterCountDate(today);
    }
  }, [waterCountDate, setWaterCount, setWaterCountDate]);

  // Update current time every second
  useEffect(() => {
    const iv = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(iv);
  }, []);

  // Request notification permission
  useEffect(() => {
    requestPermission().then((p) => setNotificationPermission(p === 'granted'));
  }, [requestPermission]);

  // Check alarms
  useEffect(() => {
    const now = currentTime;
    const nowTime = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
    const nowDate = now.toISOString().split('T')[0];
    const nowDay = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][now.getDay()];

    alarms.forEach((alarm) => {
      if (!alarm.enabled || alarm.triggered) return;
      if (alarm.time !== nowTime) return;

      const shouldRing =
        alarm.date === nowDate ||
        (alarm.repeat.length > 0 && alarm.repeat.includes(nowDay));

      if (shouldRing && now.getSeconds() < 2) {
        setRingingAlarm(alarm);
        setAlarms((prev: Alarm[]) =>
          prev.map((a) => (a.id === alarm.id ? { ...a, triggered: true } : a))
        );
        sendNotification('⏰ Alarm!', alarm.label || 'Your alarm is ringing!');

        // Play sound via audio context
        try {
          const ctx = new AudioContext();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.frequency.value = 880;
          gain.gain.setValueAtTime(0.3, ctx.currentTime);
          osc.start();
          setTimeout(() => { osc.stop(); ctx.close(); }, 1000);
        } catch {
          // ignore
        }
      }
    });

    // Reset triggered flag when minute changes
    if (now.getSeconds() === 0) {
      setAlarms((prev: Alarm[]) =>
        prev.map((a) => {
          if (a.triggered && a.time !== nowTime) {
            return { ...a, triggered: false };
          }
          return a;
        })
      );
    }
  }, [currentTime, alarms, setAlarms, sendNotification]);

  // Check water reminders
  useEffect(() => {
    const now = currentTime;
    const currentMinutes = now.getHours() * 60 + now.getMinutes();

    waterReminders.forEach((reminder) => {
      if (!reminder.enabled) return;

      const [wh, wm] = reminder.wakeTime.split(':').map(Number);
      const [sh, sm] = reminder.sleepTime.split(':').map(Number);
      const wakeMin = wh * 60 + wm;
      const sleepMin = sh * 60 + sm;

      if (currentMinutes < wakeMin || currentMinutes > sleepMin) return;

      const minutesSinceWake = currentMinutes - wakeMin;
      const isReminderTime = minutesSinceWake % reminder.intervalMinutes === 0;

      if (isReminderTime && now.getSeconds() < 2) {
        const lastTriggered = reminder.lastTriggered;
        const nowKey = `${now.toDateString()}-${now.getHours()}-${now.getMinutes()}`;
        
        if (lastTriggered !== nowKey) {
          setWaterNotifMessage(reminder.message);
          setShowWaterNotif(true);
          sendNotification('💧 Water Reminder', reminder.message);

          setWaterReminders((prev: WaterReminder[]) =>
            prev.map((r) =>
              r.id === reminder.id ? { ...r, lastTriggered: nowKey } : r
            )
          );

          // Play water drop sound
          try {
            const ctx = new AudioContext();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.frequency.value = 1200;
            osc.type = 'sine';
            gain.gain.setValueAtTime(0.2, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
            osc.start();
            osc.stop(ctx.currentTime + 0.3);
            setTimeout(() => ctx.close(), 500);
          } catch {
            // ignore
          }
        }
      }
    });
  }, [currentTime, waterReminders, setWaterReminders, sendNotification]);

  const handleDismissAlarm = useCallback(() => {
    setRingingAlarm(null);
    if (snoozeTimerRef.current) clearTimeout(snoozeTimerRef.current);
  }, []);

  const handleSnoozeAlarm = useCallback(() => {
    const alarm = ringingAlarm;
    setRingingAlarm(null);
    if (alarm) {
      snoozeTimerRef.current = window.setTimeout(() => {
        setRingingAlarm(alarm);
        sendNotification('⏰ Alarm! (Snoozed)', alarm.label || 'Your alarm is ringing again!');
      }, 5 * 60 * 1000); // 5 minutes
    }
  }, [ringingAlarm, sendNotification]);

  const formatCurrentTime = () => {
    return currentTime.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const formatCurrentDate = () => {
    return currentTime.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    });
  };

  const tabs: { id: TabType; label: string; icon: typeof AlarmClock; color: string }[] = [
    { id: 'alarm', label: 'Alarm', icon: AlarmClock, color: 'from-violet-500 to-indigo-500' },
    { id: 'water', label: 'Water', icon: Droplets, color: 'from-cyan-500 to-blue-500' },
    { id: 'stopwatch', label: 'Timer', icon: Timer, color: 'from-emerald-500 to-green-500' },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-slate-900 to-slate-950 text-white max-w-lg mx-auto relative overflow-x-hidden">
      {/* Status Bar */}
      <div className="sticky top-0 z-30 bg-slate-900/95 backdrop-blur-xl border-b border-slate-800/50">
        <div className="px-5 pt-3 pb-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-3xl font-extralight text-white tracking-wide">{formatCurrentTime()}</p>
              <p className="text-xs text-slate-400 mt-0.5">{formatCurrentDate()}</p>
            </div>
            <div className="flex items-center gap-2">
              {!notificationPermission && (
                <button
                  onClick={() => requestPermission().then((p) => setNotificationPermission(p === 'granted'))}
                  className="flex items-center gap-1.5 rounded-full bg-amber-500/15 px-3 py-1.5 text-xs text-amber-400 border border-amber-500/20"
                >
                  <Bell className="h-3 w-3" /> Enable
                </button>
              )}
              {notificationPermission && (
                <span className="flex items-center gap-1 text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded-full">
                  <Bell className="h-3 w-3" /> ON
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="min-h-[calc(100vh-140px)]">
        {activeTab === 'alarm' && <AlarmTab alarms={alarms} setAlarms={setAlarms} />}
        {activeTab === 'water' && (
          <WaterTab
            reminders={waterReminders}
            setReminders={setWaterReminders}
            waterCount={waterCount}
            setWaterCount={setWaterCount}
          />
        )}
        {activeTab === 'stopwatch' && <StopwatchTab />}
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 z-30">
        <div className="max-w-lg mx-auto">
          <div className="bg-slate-900/95 backdrop-blur-xl border-t border-slate-800/50 px-2 pt-2 pb-6">
            <div className="flex justify-around">
              {tabs.map((tab) => {
                const isActive = activeTab === tab.id;
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex flex-col items-center gap-1 px-5 py-2 rounded-2xl transition-all duration-300 ${
                      isActive
                        ? `bg-gradient-to-b ${tab.color} shadow-lg`
                        : 'text-slate-500'
                    }`}
                  >
                    <Icon className={`h-5 w-5 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                    <span className={`text-[10px] font-semibold ${isActive ? 'text-white' : 'text-slate-500'}`}>
                      {tab.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Alarm Ringing Overlay */}
      {ringingAlarm && (
        <AlarmRinging
          alarm={ringingAlarm}
          onDismiss={handleDismissAlarm}
          onSnooze={handleSnoozeAlarm}
        />
      )}

      {/* Water Notification */}
      {showWaterNotif && (
        <WaterNotification
          message={waterNotifMessage}
          onDismiss={() => setShowWaterNotif(false)}
        />
      )}
    </div>
  );
}
