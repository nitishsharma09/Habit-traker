import { useEffect, useCallback, useRef } from 'react';

export function useNotification() {
  const permissionRef = useRef<NotificationPermission>('default');

  useEffect(() => {
    if ('Notification' in window) {
      permissionRef.current = Notification.permission;
      if (Notification.permission === 'default') {
        Notification.requestPermission().then((p) => {
          permissionRef.current = p;
        });
      }
    }
  }, []);

  const sendNotification = useCallback((title: string, body: string, icon?: string) => {
    if ('Notification' in window && Notification.permission === 'granted') {
      const notification = new Notification(title, {
        body,
        icon: icon || '💧',
        badge: '⏰',
        requireInteraction: true,
      });
      
      // Auto close after 10 seconds
      setTimeout(() => notification.close(), 10000);
      return notification;
    }
    return null;
  }, []);

  const requestPermission = useCallback(async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      permissionRef.current = permission;
      return permission;
    }
    return 'denied' as NotificationPermission;
  }, []);

  return { sendNotification, requestPermission };
}
